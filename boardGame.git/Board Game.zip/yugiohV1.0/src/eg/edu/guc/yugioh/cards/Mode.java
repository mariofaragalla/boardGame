package eg.edu.guc.yugioh.cards;

public enum Mode {
	ATTACK,DEFENSE
}
